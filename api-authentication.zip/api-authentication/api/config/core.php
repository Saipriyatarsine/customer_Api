<?php
// show error reporting
error_reporting(E_ALL);
 
// set your default time-zone
date_default_timezone_set('Asia/Manila');
 
// variables used for jwt
$key = "example_key";
$iss = "http://example.org";
$aud = "http://example.com";
$iat = 1356999524;
$nbf = 1357000000;


/*
http://localhost/rest-api-authentication-example/api/login.php

Enter the following on the body.

{
    "email" : "mike@codeofaninja.com",
    "password" : "555"
}
*/
?>